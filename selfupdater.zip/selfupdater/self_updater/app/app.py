import time
from updater import perform_update_if_needed

def main():
    print("Starting app...")
    perform_update_if_needed()
    print("Running main program logic...\n")

    # Added this infinite loop to demonstrate that the app is running
    for i in range(1, 100000):
        print(f"App is running... iteration {i}")
        time.sleep(2)


if __name__ == "__main__":
    main()
