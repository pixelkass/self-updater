import os
import shutil
import tempfile
import zipfile
import hashlib
import requests
import sys
import subprocess


UPDATE_SERVER = "http://127.0.0.1:5000/latest"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION_FILE = os.path.join(BASE_DIR, "version.txt")


def read_local_version():
    if not os.path.exists(VERSION_FILE):
        return "0.0.0"
    with open(VERSION_FILE, "r") as f:
        return f.read().strip()


def write_local_version(version):
    with open(VERSION_FILE, "w") as f:
        f.write(version)


def version_tuple(v):
    return tuple(map(int, v.split(".")))


def check_for_update():
    """Fetch metadata from the update server."""
    resp = requests.get(UPDATE_SERVER, timeout=5)
    resp.raise_for_status()
    return resp.json()


def download_file(url, target_path):
    """Stream download the update ZIP."""
    with requests.get(url, stream=True) as r:
        r.raise_for_status()
        with open(target_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)


def compute_sha256(filepath):
    sha256 = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def extract_zip(zip_path, extract_to):
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_to)


def safe_replace(src, dest):
    """Replace app files atomically and cross-platform."""
    if os.path.exists(dest):
        shutil.rmtree(dest)
    shutil.move(src, dest)


def restart_program():
    """Restart the program after update."""
    python = sys.executable
    os.execv(python, [python] + sys.argv)


def perform_update_if_needed():
    local_version = read_local_version()
    metadata = check_for_update()

    latest_version = metadata["version"]
    download_url = metadata["url"]
    expected_sha = metadata["sha256"]

    print(f"Current version: {local_version}")
    print(f"Latest version: {latest_version}")

    if version_tuple(latest_version) <= version_tuple(local_version):
        print("No update needed.")
        return False

    print("Update found! Downloading...")

    temp_dir = tempfile.mkdtemp()
    zip_path = os.path.join(temp_dir, "update.zip")

    download_file(download_url, zip_path)

    # Validate checksum
    actual_sha = compute_sha256(zip_path)
    if actual_sha.lower() != expected_sha.lower():
        raise ValueError("SHA256 mismatch! Aborting update.")

    print("Checksum OK. Extracting update...")

    extracted_dir = os.path.join(temp_dir, "extracted")
    os.makedirs(extracted_dir, exist_ok=True)
    extract_zip(zip_path, extracted_dir)

    # Replace app folder
    safe_replace(extracted_dir, BASE_DIR)

    print("Update installed.")
    write_local_version(latest_version)

    print("Restarting application...")
    restart_program()
