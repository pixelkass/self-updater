import os
import shutil
import sys
import time


def safe_replace(src, dest):
    # Remove old app folder if it exists
    if os.path.exists(dest):
        print(f"Removing old app folder: {dest}")
        shutil.rmtree(dest)
    print(f"Moving new app from {src} to {dest}")
    shutil.move(src, dest)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: updater_launcher.py <temp_extracted_dir> <app_dir>")
        sys.exit(1)

    temp_dir = sys.argv[1]
    app_dir = sys.argv[2]

    print("Updater launcher started.")
    print("Waiting for main app process to exit...")
    # brief delay to ensure Python releases file handles. This was added due to an issues on Windows where the folder would get locked
    time.sleep(1)

    safe_replace(temp_dir, app_dir)

    # Restart the app
    python_exe = sys.executable
    app_path = os.path.join(app_dir, "app.py")
    print(f"Restarting app: {app_path}")
    os.execv(python_exe, [python_exe, app_path])
