import os
import subprocess
import sys

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    app_path = os.path.join(base_dir, "self_updater", "app", "app.py")

    print("Launching self-updating application...")
    subprocess.run([sys.executable, app_path])

if __name__ == "__main__":
    main()
