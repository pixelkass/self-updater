from flask import Flask, jsonify, send_from_directory, abort
import os
import re
import hashlib

app = Flask(__name__)

RELEASE_DIR = "releases"
VERSION_PATTERN = re.compile(r"app-(\d+\.\d+\.\d+)\.zip")



def compute_sha256(filepath):
    """Compute SHA256 hash of a file."""
    sha256 = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def get_latest_release():
    """Scan the releases directory and return (version, filename, sha256)."""
    versions = []

    for filename in os.listdir(RELEASE_DIR):
        match = VERSION_PATTERN.match(filename)
        if match:
            version = match.group(1)
            versions.append((version, filename))

    if not versions:
        return None

    # Sort versions semantically: 1.0.10 > 1.0.2 > 1.0.1
    def version_key(v):
        return tuple(int(part) for part in v[0].split("."))

    versions.sort(key=version_key, reverse=True)
    latest_version, latest_file = versions[0]

    full_path = os.path.join(RELEASE_DIR, latest_file)
    sha = compute_sha256(full_path)

    return {
        "version": latest_version,
        "filename": latest_file,
        "sha256": sha
    }


@app.route("/latest", methods=["GET"])
def latest():
    release = get_latest_release()
    if not release:
        return jsonify({"error": "No releases found"}), 404

    return jsonify({
        "version": release["version"],
        "url": f"http://127.0.0.1:5000/releases/{release['filename']}",
        "sha256": release["sha256"]
    })


@app.route("/releases/<path:filename>", methods=["GET"])
def download_release(filename):
    if not VERSION_PATTERN.match(filename):
        abort(404)
    return send_from_directory(RELEASE_DIR, filename, as_attachment=True)


if __name__ == "__main__":
    os.makedirs(RELEASE_DIR, exist_ok=True)
    print("Starting update server at http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000)
